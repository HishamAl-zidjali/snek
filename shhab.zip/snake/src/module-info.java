module snake {
	requires java.desktop;
}